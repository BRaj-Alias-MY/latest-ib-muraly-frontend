import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IntquestiontemplatesComponent } from './intquestiontemplates.component';

describe('IntquestiontemplatesComponent', () => {
  let component: IntquestiontemplatesComponent;
  let fixture: ComponentFixture<IntquestiontemplatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IntquestiontemplatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntquestiontemplatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
