import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrowdbulkquestionsComponent } from './crowdbulkquestions.component';

describe('CrowdbulkquestionsComponent', () => {
  let component: CrowdbulkquestionsComponent;
  let fixture: ComponentFixture<CrowdbulkquestionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrowdbulkquestionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrowdbulkquestionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
