import { Component, OnInit } from '@angular/core';
import { ViewChild } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { MastersService } from '../services/masters.service';
import Swal from 'sweetalert2/dist/sweetalert2.js';

@Component({
	selector: 'app-bulkuser',
	templateUrl: './bulkuser.component.html',
	styleUrls: [ './bulkuser.component.css' ]
})
export class BulkuserComponent implements OnInit {
	public csvRecords: any[] = [];
	public csvRecords1 = [];

    constructor(private fb: FormBuilder, private route: Router, private api: MastersService) {}
	buttonStatus;
	responsedata;
	ngOnInit() {
		this.buttonStatus = false;
	}
    
	@ViewChild('fileImportInput') fileImportInput: any;
	fileChangeListener($event: any): void {
		//alert('hi');
		var text = [];
		var files = $event.srcElement.files;
		if (this.isCSVFile(files[0])) {
			var input = $event.target;
			var reader = new FileReader();
			reader.readAsText(input.files[0]);

			reader.onload = (data) => {
				let csvData = reader.result;
				let csvRecordsArray = (csvData as string).split(/\r\n|\n/);

				let headersRow = this.getHeaderArray(csvRecordsArray);

				this.csvRecords = this.getDataRecordsArrayFromCSVFile(csvRecordsArray, headersRow.length);
			};

			reader.onerror = function() {
				Swal('Unable to read ' + input.files[0]);
			};
		} else {
			Swal('Please import valid .csv file.');
			this.fileReset();
		}
	}
	getDataRecordsArrayFromCSVFile(csvRecordsArray: any, headerLength: any) {
		var dataArr = [];

		for (let i = 1; i < csvRecordsArray.length; i++) {
			//let data = (csvRecordsArray[i] as string).split(',');
			let data = csvRecordsArray[i].match(/("[^"]*")|[^,]+/g);
			// FOR EACH ROW IN CSV FILE IF THE NUMBER OF COLUMNS
			// ARE SAME AS NUMBER OF HEADER COLUMNS THEN PARSE THE DATA
			if (data) {
				if (data.length == headerLength) {
					var csvRecord: CSVRecord = new CSVRecord();

					csvRecord.fname = data[0].trim();
					csvRecord.mname = data[1].trim();
					csvRecord.lname = data[2].trim();
					csvRecord.email = data[3].trim();
					csvRecord.phone = data[4].trim();
					csvRecord.gender = data[5].trim();
					csvRecord.status = data[6].trim();
					csvRecord.subDomainName = data[7].trim();

					dataArr.push(csvRecord);
				}
			}
		}
		let dupStatus = false;
		for (let i = 0; i < dataArr.length; i++) {
			// console.log(dataArr[i].question);
			for (let j = i + 1; j < dataArr.length; j++) {
				if (dataArr[i].email == dataArr[j].email) {
					dupStatus = true;
					break;
				}
			}
		}
		if (dupStatus) {
			//Swal('Duplicate Data.');
			//alert('Duplicate Data.');
		} else {
			console.log(dataArr);

			this.api.valid_users(dataArr).subscribe((res) => {
				if (res.status) {
					this.buttonStatus = res.status;
					this.csvRecords1 = res.message;
					this.responsedata = res;
				} else {
					this.csvRecords1 = res.message;
					this.fileReset();
					// console.log(this.csvRecords1);
					if(this.csvRecords1.length>0){
						Swal.fire('Oops..', 'Please find the Validation Column', 'error');
					 }else{
						Swal.fire('Oops..', 'No data found in file. please upload valid file', 'error');
					 }

				}
			});
			//console.log('hell0');
		
		}
		return dataArr;
	}
	// CHECK IF FILE IS A VALID CSV FILE
	isCSVFile(file: any) {
		return file.name.endsWith('.csv');
	}
	// GET CSV FILE HEADER COLUMNS
	getHeaderArray(csvRecordsArr: any) {
		let headers = (csvRecordsArr[0] as string).split(',');
		let headerArray = [];

		for (let j = 0; j < headers.length; j++) {
			headerArray.push(headers[j]);
		}
		return headerArray;
	}

	fileReset() {
		this.fileImportInput.nativeElement.value = '';
		this.csvRecords = [];
	}
	onSubmit(data) {
		//alert('hi');
		console.log(this.responsedata);
		this.api.add_users(this.responsedata).subscribe((res) => {
			if (res.status) {
				//alert('sucess');
				Swal.fire('Success..', 'Users Uploaded successfully', 'success'); 
				this.fileReset();
				this.csvRecords1 = [];

			} else {
				//this.csvRecords1 = res.message;
				// console.log(this.csvRecords1);
				Swal.fire('Oops...', 'Something went wrong!', 'error');

			}
		});
	}
}

export class CSVRecord {
	public fname: any;
	public mname: any;
	public lname: any;
	public email: any;
	public phone: any;
	public gender: any;
	public status: any;
	public subDomainName:any;
}
