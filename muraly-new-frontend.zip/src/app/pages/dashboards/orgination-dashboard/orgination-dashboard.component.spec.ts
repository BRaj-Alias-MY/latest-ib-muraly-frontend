import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrginationDashboardComponent } from './orgination-dashboard.component';

describe('OrginationDashboardComponent', () => {
  let component: OrginationDashboardComponent;
  let fixture: ComponentFixture<OrginationDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrginationDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrginationDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
