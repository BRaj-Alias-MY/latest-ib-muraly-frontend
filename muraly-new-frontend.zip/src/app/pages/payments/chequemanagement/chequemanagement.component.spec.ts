import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChequemanagementComponent } from './chequemanagement.component';

describe('ChequemanagementComponent', () => {
  let component: ChequemanagementComponent;
  let fixture: ComponentFixture<ChequemanagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChequemanagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChequemanagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
