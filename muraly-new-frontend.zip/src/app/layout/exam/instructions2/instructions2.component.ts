import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-instructions2',
  templateUrl: './instructions2.component.html',
  styleUrls: ['./instructions2.component.css']
})
export class Instructions2Component implements OnInit {

  constructor( private api:ApiService, private router: Router) { }

  ngOnInit() {
  }
  logout()  {
    this.api.logout();
    this.router.navigate(['/login']);
  }
}
